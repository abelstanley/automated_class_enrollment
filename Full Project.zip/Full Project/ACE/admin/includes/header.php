<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Atomated Class Enrolment</title>
<link href="stylesheets/public.css" media="all" rel="stylesheet" type="text/css"  />
</head>

<body>
<div id="header">
  <h1> AUTOMATED CLASS ENROLMENT </h1>
</div>
<div id="main">
