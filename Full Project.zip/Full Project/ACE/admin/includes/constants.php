<?php 
define("DB_SERVER" , "localhost");
define("DB_USER" , "root");
define("DB_PASS" , "in1992");
define("DB_NAME" , "ace");

?>