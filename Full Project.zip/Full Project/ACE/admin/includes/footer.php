<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
</div>
  
<div id="footer"> Copyright 2019, Stanley Abel. </div>
</body>
</html>
   <?php  if (isset($connect)) 
   {mysql_close ($connect);
   }
    ?>